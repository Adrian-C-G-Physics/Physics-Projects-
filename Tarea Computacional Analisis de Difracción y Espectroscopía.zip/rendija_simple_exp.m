function [ancho_rendija, g]= rendija_simple_exp(lambda,archivoExcel)

%en la segunda parte necesitamos leer los datos experimentales, he pensado
%que por comodidad, lo mejor es que lea un excel, tiene que estar muy
%ordenados esos datos, empezando por la primera columan,
%  en la 1 fila el nombre de la dato que se va leer por columna. 

data = readtable(archivoExcel);
X_min=data.X_min;
D=data.D;

%queremos hacer un ajuste lieal a los datos de Xmin y D(distancia de la red
%a la pantalla. El modelo teorico es Xmin= labda/(2a)*D ==>y=mx
%se calcual directamnete el valor de la pendiente con polyval.

m0=polyfit(D,X_min,1); %polifit da 2 valores: (m,n)
ancho_rendija=lambda/m0(1);
g=m0/lambda; 
