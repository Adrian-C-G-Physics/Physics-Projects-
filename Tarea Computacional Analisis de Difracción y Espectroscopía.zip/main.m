function main
    % ==========================================================
    % APP: Difracción y Espectroscopia
    % Por ahora: SOLO Módulo de Rendija Simple
    % ==========================================================

    % -------- Ventana principal --------
    f = uifigure('Name','Proyecto: Difracción y Espectroscopia', ...
                 'Position',[100 100 750 450]);

    % -------- Estado compartido de la app --------
    % Aquí guardamos cosas que puedan usarse en el futuro por otros módulos.
    state = struct();
    state.archivoExcelRendija = "";     % Excel seleccionado para este módulo
    state.ancho_rendija = NaN;          % NaN = no calculado
    state.archivoExcel_red = "";             % Excel para calibración de red
    state.archivoExcel_espectroscopia = "";  % Excel para espectroscopia

    state.red_2d = NaN;     % 2d en METROS (parámetro de red que se usará en espectroscopia)
    state.red_N = NaN;      % N = 1/(2d) (densidad de líneas) en líneas/mm (o en 1/m si prefieres)
    f.UserData = state;

% -------- Pestañas (TabGroup) --------
tg = uitabgroup(f, 'Position', [10 10 730 430]);

% Pestaña 1
tabRendija = uitab(tg, 'Title', 'Módulo de Rendija Simple');
crearTabRendijaSimple(f, tabRendija);

% Pestaña 2: Calibración
tabCalib = uitab(tg, 'Title', 'Módulo de Calibración de Red');
crearTabCalibracionRed(f, tabCalib);

% Pestaña 3: Espectroscopia
tabEspec = uitab(tg, 'Title', 'Módulo de Espectroscopia');
crearTabEspectroscopia(f, tabEspec);

end


% ==========================================================
% Construye la pestaña del Módulo de Rendija Simple
% ==========================================================
function crearTabRendijaSimple(fig, tab)

    % --- Título del módulo ---
    uilabel(tab, 'Text','Módulo de Rendija Simple (experimental)', ...
        'Position',[20 385 500 25], 'FontSize', 16, 'FontWeight','bold');

    % --- Campo lambda ---
    uilabel(tab, 'Text','Longitud de onda \lambda (m):', ...
        'Position',[20 340 250 22]);

    lambdaField = uieditfield(tab,'numeric', ...
        'Position',[20 315 180 22], ...
        'Value', 633e-9, ...
        'LowerLimit', 0);

    % --- Botón seleccionar Excel ---
    btnExcel = uibutton(tab, 'push', ...
        'Text','Seleccionar Excel (columnas: D y X_min)', ...
        'Position',[20 270 260 32], ...
        'ButtonPushedFcn', @seleccionarExcel);

    % --- Etiqueta para mostrar el archivo seleccionado ---
    archivoLabel = uilabel(tab, ...
        'Text','Archivo: (ninguno)', ...
        'Position',[20 245 680 22], ...
        'Interpreter','none');

    % --- Botón calcular ---
    btnCalcular = uibutton(tab, 'push', ...
        'Text','Calcular ancho de rendija', ...
        'Position',[20 195 260 36], ...
        'ButtonPushedFcn', @calcular);

    % --- Etiqueta de resultado ---
    resultadoLabel = uilabel(tab, ...
        'Text','Resultado: ancho de rendija = (no calculado)', ...
        'Position',[20 150 680 22], ...
        'Interpreter','none');

    % --- Etiqueta para información adicional, sobre el estado del cáculo  ---
    infoLabel = uilabel(tab, ...
        'Text','', ...
        'Position',[20 120 680 22], ...
        'Interpreter','none');


    % ======================================================
    % CALLBACK: seleccionar Excel
    % ======================================================
    function seleccionarExcel(~,~)
        [file, path] = uigetfile('*.xlsx','Selecciona el archivo de datos');
        if isequal(file,0)
            uialert(fig,'No se seleccionó ningún archivo Excel.','Aviso');
            return
        end

        state = fig.UserData;
        state.archivoExcelRendija = string(fullfile(path,file));
        state.ancho_rendija = NaN; % invalida resultado previo
        fig.UserData = state;

        archivoLabel.Text = "Archivo: " + state.archivoExcelRendija;
        resultadoLabel.Text = 'Resultado: ancho de rendija = (no calculado)';
        infoLabel.Text = '';
    end

    % ======================================================
    % CALLBACK: calcular
    % ======================================================
    function calcular(~,~)
        state = fig.UserData;

        % 1) Comprobar que hay archivo Excel
        if strlength(state.archivoExcelRendija) == 0
            uialert(fig,'Primero debes seleccionar un archivo Excel.','Error');
            return
        end

        % 2) Validar lambda
        lambda = lambdaField.Value;
        if isempty(lambda) || ~isfinite(lambda) || lambda <= 0
            uialert(fig,'Introduce un valor válido de \lambda (>0).','Error');
            return
        end

        % 3) Calcular (función externa)
      state.ancho_rendija = rendija_simple_exp(lambda, state.archivoExcelRendija);
        fig.UserData = state;

        % 4) Gestionar NaN
        if isnan(state.ancho_rendija)
            uialert(fig, ...
                'No se pudo calcular. Revisa el Excel (columnas D y X_min) y que los datos sean numéricos.', ...
                'Error de cálculo');
            resultadoLabel.Text = 'Resultado: ancho de rendija = (no calculado)';
            infoLabel.Text = 'Sugerencia: comprueba nombres de columnas "D" y ""X_min y unidades (m).';
            return
        end

        % 5) Mostrar resultado
        resultadoLabel.Text = sprintf('Resultado: ancho de rendija = %.3e m', state.ancho_rendija);
        infoLabel.Text = 'Cálculo realizado correctamente.';
    end
% ==========================================================
% PANEL SIMULACIÓN (independiente del Excel)
% ==========================================================
panelSim = uipanel(tab, ...
    'Title','Simulación Fraunhofer (independiente del Excel)', ...
    'Position',[320 40 390 330]);

% Entrada ancho total 2a
uilabel(panelSim,'Text','Ancho total (2a) [m]:', ...
    'Position',[15 270 180 22]);
anchoSimField = uieditfield(panelSim,'numeric', ...
    'Position',[200 270 150 22], ...
    'Value',1e-4, 'LowerLimit',0);

% Entrada lambda (SIMULACIÓN)
uilabel(panelSim,'Text','\lambda (simulación) [m]:', ...
    'Position',[15 235 180 22]);
lambdaSimField = uieditfield(panelSim,'numeric', ...
    'Position',[200 235 150 22], ...
    'Value',633e-9, 'LowerLimit',0);

% Entrada I0
uilabel(panelSim,'Text','I0 (escala):', ...
    'Position',[15 200 180 22]);
I0Field = uieditfield(panelSim,'numeric', ...
    'Position',[200 200 150 22], ...
    'Value',1, 'LowerLimit',0);

% Rango theta (±thetaMax)
uilabel(panelSim,'Text','Rango \theta (±) [rad]:', ...
    'Position',[15 165 180 22]);
thetaMaxField = uieditfield(panelSim,'numeric', ...
    'Position',[200 165 150 22], ...
    'Value',0.02, 'LowerLimit',1e-6);

% Botón para graficar
btnPlot = uibutton(panelSim,'push', ...
    'Text','Graficar I(\theta)', ...
    'Position',[15 125 335 30], ...
    'ButtonPushedFcn',@graficarSim);

% Ejes dentro del panel
ax = uiaxes(panelSim, 'Position',[15 10 355 105]);
ax.XLabel.String = '\theta (rad)';
ax.YLabel.String = 'I(\theta)';
grid(ax,'on');
ax.Title.String = 'Perfil de intensidad (Fraunhofer)';

% ==========================================================
% CALLBACK: graficar simulación (NO toca el Excel)
% ==========================================================
function graficarSim(~,~)
    W      = anchoSimField.Value;   % 2a
    lamSim = lambdaSimField.Value;
    I0     = I0Field.Value;
    thMax  = thetaMaxField.Value;

    % Validaciones básicas
    if ~isfinite(W) || W <= 0
        uialert(fig,'Introduce un ancho total 2a válido (>0).','Error');
        return
    end
    if ~isfinite(lamSim) || lamSim <= 0
        uialert(fig,'Introduce una \lambda válida (>0).','Error');
        return
    end
    if ~isfinite(I0) || I0 < 0
        uialert(fig,'Introduce un I0 válido (>=0).','Error');
        return
    end
    if ~isfinite(thMax) || thMax <= 0
        uialert(fig,'Introduce un rango de \theta válido (>0).','Error');
        return
    end

    % Simular (función externa, NO Excel)
    [thetaVec, I_red] = rendija_simple_sim(W, lamSim, I0, thMax);

    % Graficar en el uiaxes del panel
    plot(ax, thetaVec, I_red, 'k', 'LineWidth', 1.5);
    grid(ax,'on');
end

end

%creamos la tabla de calibracion 
function crearTabCalibracionRed(fig, tab)

    uilabel(tab, 'Text','Módulo de Calibración de Red', ...
        'Position',[20 385 650 25], 'FontSize', 16, 'FontWeight','bold');

    panelRed = uipanel(tab, 'Title','Calibración de la Red', 'Position',[20 40 690 330]);

    uilabel(panelRed,'Text','Longitud de onda \lambda (m):', 'Position',[20 270 200 22]);

    lambdaRedField = uieditfield(panelRed,'numeric', ...
        'Position',[20 245 160 22], 'Value',633e-9, 'LowerLimit',0);

    btnExcelRed = uibutton(panelRed,'push', ...
        'Text','Seleccionar Excel (D y X_{max})', ...
        'Position',[20 205 260 30], ...
        'ButtonPushedFcn',@seleccionarExcelRed);

    archivoRedLabel = uilabel(panelRed, ...
        'Text','Archivo: (ninguno)', ...
        'Position',[20 180 650 22], ...
        'Interpreter','none');

    btnCalibrar = uibutton(panelRed,'push', ...
        'Text','Calibrar red', ...
        'Position',[20 135 260 34], ...
        'ButtonPushedFcn',@calibrarRed);

    red2dLabel = uilabel(panelRed, ...
        'Text','2d = (no calculado)', ...
        'Position',[20 95 650 22], ...
        'Interpreter','none');

    redNLabel = uilabel(panelRed, ...
        'Text','N = 1/(2d) = (no calculado)', ...
        'Position',[20 70 650 22], ...
        'Interpreter','none');

    redInfoLabel = uilabel(panelRed, ...
        'Text','', ...
        'Position',[20 45 650 22], ...
        'Interpreter','none');

    % ---------- Callbacks ----------
    function seleccionarExcelRed(~,~)
        [file, path] = uigetfile('*.xlsx','Selecciona el Excel de calibración (D, X_max)');
        if isequal(file,0), return; end

        st = fig.UserData;
        st.archivoExcel_red = string(fullfile(path,file));
        fig.UserData = st;

        archivoRedLabel.Text = "Archivo: " + st.archivoExcel_red;
        redInfoLabel.Text = '';
    end

    function calibrarRed(~,~)
        st = fig.UserData;

        if strlength(st.archivoExcel_red)==0
            uialert(fig,'Selecciona primero un Excel para calibración de red.','Falta Excel');
            return
        end

        lambda = lambdaRedField.Value;
        if ~isfinite(lambda) || lambda<=0
            uialert(fig,'Introduce un valor válido de \lambda (>0).','Error');
            return
        end

        [red_2d, red_N] = calibracion_red_exp(lambda, st.archivoExcel_red);

        if any(~isfinite(red_2d(:))) || any(~isfinite(red_N(:)))
            uialert(fig,'No se pudo calibrar la red. Revisa el Excel y datos.','Error de cálculo');
            redInfoLabel.Text = 'Revisa columnas, unidades y valores.';
            return
        end

        st.red_2d = red_2d;
        st.red_N  = red_N;     % guardado en 1/m
        fig.UserData = st;

        N_lineas_mm = st.red_N / 1e3;   % 1/m -> líneas/mm (solo display)
        red2dLabel.Text = sprintf('2d = %.6e m', st.red_2d);
        redNLabel.Text  = sprintf('N = 1/(2d) = %.3f líneas/mm', N_lineas_mm);
        redInfoLabel.Text = 'Calibración correcta. Valor guardado para espectroscopia.';
    end

end


%creamos la taba de espectroscopia
function crearTabEspectroscopia(fig, tab)

    uilabel(tab, 'Text','Módulo de Espectroscopia', ...
        'Position',[20 385 650 25], 'FontSize', 16, 'FontWeight','bold');

    panelEsp = uipanel(tab, 'Title','Espectroscopia', 'Position',[20 40 690 330]);

    % Mostrar 2d del módulo de calibración (SUBIDO un poco)
    usa2dLabel = uilabel(panelEsp, ...
        'Text','2d (módulo calibración): (no calculado)', ...
        'Position',[370, 285 650 22], 'Interpreter','none');

    % Texto fijo: ángulos en grados (SUBIDO)
    uilabel(panelEsp,'Text','Ángulos en GRADOS (según Excel)', ...
        'Position',[20 272 650 22]);

    % Selector auto/manual (SUBIDO y con margen)
    bg2d = uibuttongroup(panelEsp, ...
        'Title','Origen de 2d', ...
        'Position',[20 185 330 85], ...
        'SelectionChangedFcn', @cambiarModo2d);

    rbAuto = uiradiobutton(bg2d, ...
        'Text','Usar 2d del módulo de calibración', ...
        'Position',[10 42 300 22]);

    rbManual = uiradiobutton(bg2d, ...
        'Text','Introducir 2d manualmente', ...
        'Position',[10 18 250 22]);

    % Campo numérico 2d manual (SUBIDO)
    uilabel(panelEsp,'Text','2d manual (m):', ...
        'Position',[370 232 110 22]);

    edit2dManual = uieditfield(panelEsp,'numeric', ...
        'Position',[480 232 190 22], ...
        'Value', 6.67e-6, ...
        'LowerLimit', 0);

    bg2d.SelectedObject = rbAuto;
    edit2dManual.Enable = 'off';

    % Excel espectroscopia (SUBIDO)
    btnExcelEsp = uibutton(panelEsp,'push', ...
        'Text','Seleccionar Excel (Max_central y angulo)', ...
        'Position',[370 190 300 30], ...
        'ButtonPushedFcn',@seleccionarExcelEsp);

    % Label archivo (SUBIDO y con altura menor para que no pise)
    archivoEspLabel = uilabel(panelEsp, ...
        'Text','Archivo: (ninguno)', ...
        'Position',[370 168 300 18], ...
        'Interpreter','none');

    % Botón calcular (SUBIDO)
    btnEspectro = uibutton(panelEsp,'push', ...
        'Text','Calcular \lambda_i y abrir espectro', ...
        'Position',[370 135 300 30], ...
        'ButtonPushedFcn',@calcularEspectro);

    % Info label (MOVIDO para NO SOLAPAR con archivo)
    espInfoLabel = uilabel(panelEsp, ...
        'Text','', ...
        'Position',[20 135 330 18], ...
        'Interpreter','none');

    % Tabla grande (un pelín más baja/compacta para dejar margen arriba)
    tabla = uitable(panelEsp, ...
        'Position',[20 10 650 115]);

    refrescar2dLabel();

    % ---------- helpers ----------
    function refrescar2dLabel()
        st = fig.UserData;
        if isfield(st,'red_2d') && isfinite(st.red_2d)
            usa2dLabel.Text = sprintf('2d (módulo calibración): %.6e m', st.red_2d);
        else
            usa2dLabel.Text = '2d (módulo calibración): (no calculado)';
        end
    end

    function cambiarModo2d(~, event)
        if event.NewValue == rbManual
            edit2dManual.Enable = 'on';
        else
            edit2dManual.Enable = 'off';
        end
    end

    % ---------- callbacks ----------
    function seleccionarExcelEsp(~,~)
        [file, path] = uigetfile('*.xlsx','Selecciona el Excel de espectroscopia (Max_central, angulo)');
        if isequal(file,0), return; end

        st = fig.UserData;
        st.archivoExcel_espectroscopia = string(fullfile(path,file));
        fig.UserData = st;

        archivoEspLabel.Text = "Archivo: " + st.archivoExcel_espectroscopia;
        espInfoLabel.Text = '';
    end

    function calcularEspectro(~,~)
        st = fig.UserData;

        % Elegir 2d (auto o manual)
        if bg2d.SelectedObject == rbAuto
            if ~isfield(st,'red_2d') || ~isfinite(st.red_2d) || st.red_2d <= 0
                uialert(fig,'No hay 2d calculado. Cambia a manual o calibra la red.','Falta 2d');
                refrescar2dLabel();
                return
            end
            red_2d_usado = st.red_2d;
        else
            red_2d_usado = edit2dManual.Value;
            if ~isfinite(red_2d_usado) || red_2d_usado <= 0
                uialert(fig,'Introduce un valor válido de 2d manual (>0).','Error 2d manual');
                return
            end
        end

        if ~isfield(st,'archivoExcel_espectroscopia') || strlength(st.archivoExcel_espectroscopia)==0
            uialert(fig,'Selecciona primero un Excel con Max_central y angulo.','Falta Excel');
            return
        end

        % TU FUNCIÓN
        [T, lambda_nm] = espectroscopia_exp(red_2d_usado, st.archivoExcel_espectroscopia);

        if isempty(T) || isempty(lambda_nm)
            uialert(fig,'No se pudieron calcular longitudes de onda.','Error');
            return
        end

        tabla.Data = T;
        tabla.ColumnName = T.Properties.VariableNames;

        lambda_plot = lambda_nm(:);
        if max(lambda_plot) < 1e-3
            lambda_plot = lambda_plot * 1e9;
        end

        figure('Name','Espectro (líneas verticales)','NumberTitle','off');
        hold on; grid on;
        ylim([0 1]); yticks([]);
        xlabel('\lambda (nm)');
        title('Espectro');
        xlim([max(0, min(lambda_plot)-30), max(lambda_plot)+30]);

        for k = 1:numel(lambda_plot)
            line([lambda_plot(k) lambda_plot(k)], [0 1], 'LineWidth', 2);
        end
        hold off;

        espInfoLabel.Text = sprintf('OK: %d líneas (gráfico en ventana aparte).', numel(lambda_plot));
        refrescar2dLabel();
    end

end

