function main
    % ==========================================================
    % APP: Difracción y Espectroscopia
    % Por ahora: SOLO Módulo de Rendija Simple
    % ==========================================================

    % -------- Ventana principal --------
    f = uifigure('Name','Proyecto: Difracción y Espectroscopia', ...
                 'Position',[100 100 750 450]);

    % -------- Estado compartido de la app --------
    % Aquí guardamos cosas que puedan usarse en el futuro por otros módulos.
    state = struct();
    state.archivoExcelRendija = "";     % Excel seleccionado para este módulo
    state.ancho_rendija = NaN;          % NaN = no calculado
    state.archivoExcel_red = "";             % Excel para calibración de red
    state.archivoExcel_espectroscopia = "";  % Excel para espectroscopia

    state.red_2d = NaN;     % 2d en METROS (parámetro de red que se usará en espectroscopia)
    state.red_N = NaN;      % N = 1/(2d) (densidad de líneas) en líneas/mm (o en 1/m si prefieres)
    f.UserData = state;

    % -------- Pestañas (TabGroup) --------
    tg = uitabgroup(f, 'Position', [10 10 730 430]);

    % Por ahora solo 1 pestaña:
    tabRendija = uitab(tg, 'Title', 'Módulo de Rendija Simple');

    % Construir la interfaz del módulo 1
    crearTabRendijaSimple(f, tabRendija);

    %igual para la 2º pestaña
    tabRedEspec = uitab(tg, 'Title', 'Módulo de Calibración de Red y Espectroscopia');
    crearTabRedEspectroscopia(f, tabRedEspec);

end


% ==========================================================
% Construye la pestaña del Módulo de Rendija Simple
% ==========================================================
function crearTabRendijaSimple(fig, tab)

    % --- Título del módulo ---
    uilabel(tab, 'Text','Módulo de Rendija Simple (experimental)', ...
        'Position',[20 385 500 25], 'FontSize', 16, 'FontWeight','bold');

    % --- Campo lambda ---
    uilabel(tab, 'Text','Longitud de onda \lambda (m):', ...
        'Position',[20 340 250 22]);

    lambdaField = uieditfield(tab,'numeric', ...
        'Position',[20 315 180 22], ...
        'Value', 633e-9, ...
        'LowerLimit', 0);

    % --- Botón seleccionar Excel ---
    btnExcel = uibutton(tab, 'push', ...
        'Text','Seleccionar Excel (columnas: D y X_min)', ...
        'Position',[20 270 260 32], ...
        'ButtonPushedFcn', @seleccionarExcel);

    % --- Etiqueta para mostrar el archivo seleccionado ---
    archivoLabel = uilabel(tab, ...
        'Text','Archivo: (ninguno)', ...
        'Position',[20 245 680 22], ...
        'Interpreter','none');

    % --- Botón calcular ---
    btnCalcular = uibutton(tab, 'push', ...
        'Text','Calcular ancho de rendija', ...
        'Position',[20 195 260 36], ...
        'ButtonPushedFcn', @calcular);

    % --- Etiqueta de resultado ---
    resultadoLabel = uilabel(tab, ...
        'Text','Resultado: ancho de rendija = (no calculado)', ...
        'Position',[20 150 680 22], ...
        'Interpreter','none');

    % --- Etiqueta para información adicional, sobre el estado del cáculo  ---
    infoLabel = uilabel(tab, ...
        'Text','', ...
        'Position',[20 120 680 22], ...
        'Interpreter','none');


    % ======================================================
    % CALLBACK: seleccionar Excel
    % ======================================================
    function seleccionarExcel(~,~)
        [file, path] = uigetfile('*.xlsx','Selecciona el archivo de datos');
        if isequal(file,0)
            uialert(fig,'No se seleccionó ningún archivo Excel.','Aviso');
            return
        end

        state = fig.UserData;
        state.archivoExcelRendija = string(fullfile(path,file));
        state.ancho_rendija = NaN; % invalida resultado previo
        fig.UserData = state;

        archivoLabel.Text = "Archivo: " + state.archivoExcelRendija;
        resultadoLabel.Text = 'Resultado: ancho de rendija = (no calculado)';
        infoLabel.Text = '';
    end

    % ======================================================
    % CALLBACK: calcular
    % ======================================================
    function calcular(~,~)
        state = fig.UserData;

        % 1) Comprobar que hay archivo Excel
        if strlength(state.archivoExcelRendija) == 0
            uialert(fig,'Primero debes seleccionar un archivo Excel.','Error');
            return
        end

        % 2) Validar lambda
        lambda = lambdaField.Value;
        if isempty(lambda) || ~isfinite(lambda) || lambda <= 0
            uialert(fig,'Introduce un valor válido de \lambda (>0).','Error');
            return
        end

        % 3) Calcular (función externa)
      state.ancho_rendija = rendija_simple_exp(lambda, state.archivoExcelRendija);
        fig.UserData = state;

        % 4) Gestionar NaN
        if isnan(state.ancho_rendija)
            uialert(fig, ...
                'No se pudo calcular. Revisa el Excel (columnas D y X_min) y que los datos sean numéricos.', ...
                'Error de cálculo');
            resultadoLabel.Text = 'Resultado: ancho de rendija = (no calculado)';
            infoLabel.Text = 'Sugerencia: comprueba nombres de columnas "D" y ""X_min y unidades (m).';
            return
        end

        % 5) Mostrar resultado
        resultadoLabel.Text = sprintf('Resultado: ancho de rendija = %.3e m', state.ancho_rendija);
        infoLabel.Text = 'Cálculo realizado correctamente.';
    end
% ==========================================================
% PANEL SIMULACIÓN (independiente del Excel)
% ==========================================================
panelSim = uipanel(tab, ...
    'Title','Simulación Fraunhofer (independiente del Excel)', ...
    'Position',[320 40 390 330]);

% Entrada ancho total 2a
uilabel(panelSim,'Text','Ancho total (2a) [m]:', ...
    'Position',[15 270 180 22]);
anchoSimField = uieditfield(panelSim,'numeric', ...
    'Position',[200 270 150 22], ...
    'Value',1e-4, 'LowerLimit',0);

% Entrada lambda (SIMULACIÓN)
uilabel(panelSim,'Text','\lambda (simulación) [m]:', ...
    'Position',[15 235 180 22]);
lambdaSimField = uieditfield(panelSim,'numeric', ...
    'Position',[200 235 150 22], ...
    'Value',633e-9, 'LowerLimit',0);

% Entrada I0
uilabel(panelSim,'Text','I0 (escala):', ...
    'Position',[15 200 180 22]);
I0Field = uieditfield(panelSim,'numeric', ...
    'Position',[200 200 150 22], ...
    'Value',1, 'LowerLimit',0);

% Rango theta (±thetaMax)
uilabel(panelSim,'Text','Rango \theta (±) [rad]:', ...
    'Position',[15 165 180 22]);
thetaMaxField = uieditfield(panelSim,'numeric', ...
    'Position',[200 165 150 22], ...
    'Value',0.02, 'LowerLimit',1e-6);

% Botón para graficar
btnPlot = uibutton(panelSim,'push', ...
    'Text','Graficar I(\theta)', ...
    'Position',[15 125 335 30], ...
    'ButtonPushedFcn',@graficarSim);

% Ejes dentro del panel
ax = uiaxes(panelSim, 'Position',[15 10 355 105]);
ax.XLabel.String = '\theta (rad)';
ax.YLabel.String = 'I(\theta)';
grid(ax,'on');
ax.Title.String = 'Perfil de intensidad (Fraunhofer)';

% ==========================================================
% CALLBACK: graficar simulación (NO toca el Excel)
% ==========================================================
function graficarSim(~,~)
    W      = anchoSimField.Value;   % 2a
    lamSim = lambdaSimField.Value;
    I0     = I0Field.Value;
    thMax  = thetaMaxField.Value;

    % Validaciones básicas
    if ~isfinite(W) || W <= 0
        uialert(fig,'Introduce un ancho total 2a válido (>0).','Error');
        return
    end
    if ~isfinite(lamSim) || lamSim <= 0
        uialert(fig,'Introduce una \lambda válida (>0).','Error');
        return
    end
    if ~isfinite(I0) || I0 < 0
        uialert(fig,'Introduce un I0 válido (>=0).','Error');
        return
    end
    if ~isfinite(thMax) || thMax <= 0
        uialert(fig,'Introduce un rango de \theta válido (>0).','Error');
        return
    end

    % Simular (función externa, NO Excel)
    [thetaVec, I_red] = rendija_simple_sim(W, lamSim, I0, thMax);

    % Graficar en el uiaxes del panel
    plot(ax, thetaVec, I_red, 'k', 'LineWidth', 1.5);
    grid(ax,'on');
end

end
function crearTabRedEspectroscopia(fig, tab)

    % ======================================================
    % TÍTULO
    % ======================================================
    uilabel(tab, 'Text','Módulo de Calibración de Red y Espectroscopia', ...
        'Position',[20 385 650 25], 'FontSize', 16, 'FontWeight','bold');

    % ======================================================
    % PANEL IZQUIERDA: CALIBRACIÓN DE RED
    % ======================================================
    panelRed = uipanel(tab, ...
        'Title','Calibración de la Red', ...
        'Position',[20 40 330 330]);

    % Lambda para calibración (la ecuación de tu enunciado usa λ)
    uilabel(panelRed,'Text','Longitud de onda \lambda (m):', ...
        'Position',[15 265 200 22]);

    lambdaRedField = uieditfield(panelRed,'numeric', ...
        'Position',[15 240 150 22], ...
        'Value',633e-9, ...
        'LowerLimit',0);

    % Selección Excel calibración
    btnExcelRed = uibutton(panelRed,'push', ...
        'Text','Seleccionar Excel (D y X_{max})', ...
        'Position',[15 200 250 30], ...
        'ButtonPushedFcn',@seleccionarExcelRed);

    archivoRedLabel = uilabel(panelRed, ...
        'Text','Archivo: (ninguno)', ...
        'Position',[15 175 300 22], ...
        'Interpreter','none');

    % Botón calcular calibración
    btnCalibrar = uibutton(panelRed,'push', ...
        'Text','Calibrar red', ...
        'Position',[15 135 250 34], ...
        'ButtonPushedFcn',@calibrarRed);

    % Resultados calibración
    red2dLabel = uilabel(panelRed, ...
        'Text','2d = (no calculado)', ...
        'Position',[15 95 300 22], ...
        'Interpreter','none');

    redNLabel = uilabel(panelRed, ...
        'Text','N = 1/(2d) = (no calculado)', ...
        'Position',[15 70 300 22], ...
        'Interpreter','none');

    redInfoLabel = uilabel(panelRed, ...
        'Text','', ...
        'Position',[15 45 300 22], ...
        'Interpreter','none');


    % ======================================================
    % PANEL DERECHA: ESPECTROSCOPIA
    % ======================================================
    panelEsp = uipanel(tab, ...
        'Title','Espectroscopia', ...
        'Position',[380 40 330 330]);

    % Mostrar 2d disponible (del módulo anterior)
    usa2dLabel = uilabel(panelEsp, ...
        'Text','2d disponible: (no calculado)', ...
        'Position',[15 265 300 22], ...
        'Interpreter','none');

    % Unidades del ángulo
    uilabel(panelEsp,'Text','Unidades de \theta en el Excel:', ...
        'Position',[15 235 200 22]);


    % Selección Excel espectroscopia
    btnExcelEsp = uibutton(panelEsp,'push', ...
        'Text','Seleccionar Excel (\theta_i)', ...
        'Position',[15 195 250 30], ...
        'ButtonPushedFcn',@seleccionarExcelEsp);

    archivoEspLabel = uilabel(panelEsp, ...
        'Text','Archivo: (ninguno)', ...
        'Position',[15 170 300 22], ...
        'Interpreter','none');

    % Botón calcular espectro
    btnEspectro = uibutton(panelEsp,'push', ...
        'Text','Calcular \lambda_i y mostrar espectro', ...
        'Position',[15 130 290 34], ...
        'ButtonPushedFcn',@calcularEspectro);

    espInfoLabel = uilabel(panelEsp, ...
        'Text','', ...
        'Position',[15 105 300 22], ...
        'Interpreter','none');

    % Tabla resultados (dentro del panel espectroscopia)
    tabla = uitable(panelEsp, ...
        'Position',[15 10 300 90]);

   

    % ======================================================
    % Helpers internos
    % ======================================================

    
    refrescar2dLabel();

    function refrescar2dLabel()
        st = fig.UserData;
        if isfield(st,'red_2d') && isfinite(st.red_2d)
            usa2dLabel.Text = sprintf('2d disponible: %.6e m', st.red_2d);
        else
            usa2dLabel.Text = '2d disponible: (no calculado)';
        end
    end


    % ======================================================
    % CALLBACKS: Excel + Cálculos
    % ======================================================
    function seleccionarExcelRed(~,~)
        [file, path] = uigetfile('*.xlsx','Selecciona el Excel de calibración (D, X_max)');
        if isequal(file,0), return; end

        st = fig.UserData;
        st.archivoExcel_red = string(fullfile(path,file));
        fig.UserData = st;

        archivoRedLabel.Text = "Archivo: " + st.archivoExcel_red;
        redInfoLabel.Text = '';
    end

    function calibrarRed(~,~)
        st = fig.UserData;

        if strlength(st.archivoExcel_red)==0
            uialert(fig,'Selecciona primero un Excel para calibración de red.','Falta Excel');
            return
        end

        lambda = lambdaRedField.Value;
        if ~isfinite(lambda) || lambda<=0
            uialert(fig,'Introduce un valor válido de \lambda (>0).','Error');
            return
        end

        % ======= LLAMADA A TU FUNCIÓN  =======
        % Debe devolver 2d (m) y N (líneas/mm) como mínimo
        [red_2d, red_N] = calibracion_red_exp(lambda, st.archivoExcel_red);
        % ================================================

       if any(~isfinite(red_2d(:))) || any(~isfinite(red_N(:)))
            uialert(fig,'No se pudo calibrar la red. Revisa el Excel y datos.','Error de cálculo');
            redInfoLabel.Text = 'Revisa columnas, unidades y valores.';
            return
        end

        st.red_2d = red_2d;
        st.red_N  = red_N;
        fig.UserData = st;
        N_lineas_mm = st.red_N / 1e3;     % (1/m) -> (1/mm)
        redNLabel.Text = sprintf('N = 1/(2d) = %.3f líneas/mm', N_lineas_mm);
        red2dLabel.Text = sprintf('2d = %.6e m', st.red_2d);

        redInfoLabel.Text = 'Calibración correcta. Valor guardado para espectroscopia.';

        refrescar2dLabel();
    end

    function seleccionarExcelEsp(~,~)
        [file, path] = uigetfile('*.xlsx','Selecciona el Excel de espectroscopia (theta)');
        if isequal(file,0), return; end

        st = fig.UserData;
        st.archivoExcel_espectroscopia = string(fullfile(path,file));
        fig.UserData = st;

        archivoEspLabel.Text = "Archivo: " + st.archivoExcel_espectroscopia;
        espInfoLabel.Text = '';
    end

    function calcularEspectro(~,~)
    st = fig.UserData;

    if ~isfield(st,'red_2d') || ~isfinite(st.red_2d)
        uialert(fig,'Primero calibra la red (necesito 2d).','Falta 2d');
        refrescar2dLabel();
        return
    end

    if strlength(st.archivoExcel_espectroscopia)==0
        uialert(fig,'Selecciona primero un Excel con los ángulos \theta_i.','Falta Excel');
        return
    end

    % ======= LLAMADA A TU FUNCIÓN =======
    [T, lambda_nm] = espectroscopia_exp(st.red_2d, st.archivoExcel_espectroscopia);
    % ===================================

    if isempty(T)
        uialert(fig,'No se pudieron calcular longitudes de onda.','Error');
        return
    end

    % Mostrar tabla (esto se queda igual)
    tabla.Data = T;
    tabla.ColumnName = T.Properties.VariableNames;

    if isempty(lambda_nm)
        espInfoLabel.Text = 'Tabla calculada, pero no hay datos para graficar.';
        return
    end
    

    % -----------------------------
    % ABRIR FIGURA APARTE Y GRAFICAR
    % -----------------------------
    lambda_plot = lambda_nm(:);

    % Si "lambda_nm" viene realmente en metros (muy probable), convierto SOLO para el plot:
    if max(lambda_plot) < 1e-3
        lambda_plot = lambda_plot * 1e9;  % m -> nm (solo visual)
    end

    figure('Name','Espectro (líneas verticales)','NumberTitle','off');
    hold on; grid on;

    ylim([0 1]);
    yticks([]);
    xlabel('\lambda (nm)');
    title('Espectro');

    xlim([max(0, min(lambda_plot)-30), max(lambda_plot)+30]);

    for k = 1:numel(lambda_plot)
        line([lambda_plot(k) lambda_plot(k)], [0 1], 'LineWidth', 2);
        % Si quieres color realista, cambia la línea anterior por:
        % rgb = wavelength2rgb(lambda_plot(k));
        % line([lambda_plot(k) lambda_plot(k)], [0 1], 'LineWidth', 2, 'Color', rgb);
    end

    hold off;

    espInfoLabel.Text = sprintf('Calculadas %d líneas espectrales (gráfico en ventana aparte).', numel(lambda_plot));
    refrescar2dLabel();
end
        st = fig.UserData;

        if ~isfield(st,'red_2d') || ~isfinite(st.red_2d)
            uialert(fig,'Primero calibra la red (necesito 2d).','Falta 2d');
            refrescar2dLabel();
            return
        end

        if strlength(st.archivoExcel_espectroscopia)==0
            uialert(fig,'Selecciona primero un Excel con los ángulos \theta_i.','Falta Excel');
            return
        end


        % ======= LLAMADA A TU FUNCIÓN  =======
        % Debe devolver tabla con theta y lambda (nm), y el vector lambda_nm
        [T, lambda_nm] = espectroscopia_exp(st.red_2d, st.archivoExcel_espectroscopia);
        % ================================================

        if isempty(T)
            uialert(fig,'No se pudieron calcular longitudes de onda.','Error');
            return
        end

        % Tabla
        tabla.Data = T;
        tabla.ColumnName = T.Properties.VariableNames;

        % Gráfico espectro: líneas verticales
        cla(ax);
        grid(ax,'on');
        ax.YLim = [0 1];

        if isempty(lambda_nm)
            espInfoLabel.Text = 'Tabla calculada, pero no hay datos para graficar.';
            return
        end

        ax.XLim = [max(0,min(lambda_nm)-30), max(lambda_nm)+30];

        % Aquí dibujas líneas. El color lo puedes decidir tú en tu función,
        % o usar una helper wavelength->RGB (lo hacemos luego).
        for k = 1:numel(lambda_nm)
            line(ax, [lambda_nm(k) lambda_nm(k)], [0 1], 'LineWidth', 2);
        end

        espInfoLabel.Text = sprintf('Calculadas %d líneas espectrales.', numel(lambda_nm));
        refrescar2dLabel();
    end
