function [T, lambda_nm] = espectroscopia_exp(red_2d, archivoExcel_espectroscopia)
% ENTRADAS:
%   red_2d -> 2d en metros (m), obtenido en calibración
%   archivoExcel_espectroscopia -> excel con columna theta (grados o radianes)

data=readtable(archivoExcel_espectroscopia);
maximo_central=data.Max_central;
theta=data.angulo;

% SALIDAS:
%   T -> tabla con (por ejemplo) theta, lambda_m, lambda_nm
%   lambda_nm -> vector numérico con lambdas en nm (para graficar líneas)
%
% cálculo: lambda_i = 2d * sin(theta_i)
theta_i = abs(theta-maximo_central); % Convert theta to radians if in degrees
lambda_nm = red_2d * sind(theta_i);
T = table(theta, lambda_nm, 'VariableNames', {'Theta', 'Lambda_nm'});
end