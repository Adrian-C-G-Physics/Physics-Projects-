

%definicmos uan fucnión para cauclar el petron de intendiada%
%va a necesitar que el usuario de la info de 2a, la longitud de onda con la
%k trabaja, la I0   y el rango del angulo sobre el que quiere ver la
%grafica
function [thetaVec, I_red] = rendija_simple_sim(ancho_tot_rendija, lambda, I0, thetaMax)
% Calcula I(theta) para rendija simple (Fraunhofer)
% Entradas:
%   ancho_tot_rendija = 2a (m)
%   lambda            = (m)
%   I0                = escala
%   thetaMax          = rango ±thetaMax (rad)
% Salidas:
%   thetaVec, I_red

    thetaVec = linspace(-thetaMax, thetaMax, 5000); 
%cramos un lienaspace de la variable theta sobre la que correr nuestar función
    beta = (pi * ancho_tot_rendija .* sin(thetaVec)) ./ lambda; %conviene definir esta vector

    % Evitar 0/0 en beta=0:
    I_red = I0 * (sin(beta)./beta).^2;
    I_red(beta==0) = I0;   % límite cuando beta->0
end





 