function [red_2d, red_N] = calibracion_red_exp(lambda, archivoExcel_red)
% ENTRADAS:
%   lambda           -> longitud de onda usada en calibración (m)
%   archivoExcel_red -> excel con columnas: D y X_max (en m)
data = readtable(archivoExcel_red);
X_max=data.X_max;
D=data.D;

% SALIDAS:
%   red_2d -> 2d en metros (m)
%   red_N  -> N = 1/(2d) en líneas/mm (según el enunciado)
%

m0=polyfit(D,X_max,1); %polifit da 2 valores: (m,n)
red_2d=lambda/m0(1);
red_N=m0(1)/lambda; 


end